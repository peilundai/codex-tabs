import assert from "node:assert/strict";
import test from "node:test";
import {
  MANAGED_TITLE_ARGUMENTS,
  sessionArguments,
} from "../src/sessionLaunch";

test("new, resume, and fork request generated thread titles", () => {
  const global = ["--model", "gpt-5.6-terra"];
  const managed = [...global, ...MANAGED_TITLE_ARGUMENTS];
  assert.deepEqual(sessionArguments(global, "new"), managed);
  assert.deepEqual(sessionArguments(global, "resume"), [...managed, "resume"]);
  assert.deepEqual(sessionArguments(global, "fork"), [...managed, "fork"]);
});
