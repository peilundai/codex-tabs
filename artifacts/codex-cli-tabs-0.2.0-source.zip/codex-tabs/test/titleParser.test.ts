import assert from "node:assert/strict";
import test from "node:test";
import {
  compactTitle,
  consumeOscTitles,
  titleFromCodexOsc,
} from "../src/titleParser";

test("Codex titles normalize and compact the session portion", () => {
  assert.equal(
    titleFromCodexOsc("Codex - Refactor the authentication middleware - app", 24),
    "Refactor the authentica…",
  );
  assert.equal(titleFromCodexOsc("Codex - app"), "Codex CLI");
  assert.equal(
    titleFromCodexOsc("Codex | Refactor the authentication middleware", 24),
    "Refactor the authentica…",
  );
  assert.equal(titleFromCodexOsc("Codex CLI | Generated name"), "Generated name");
  assert.equal(titleFromCodexOsc("zsh"), undefined);
  assert.equal(compactTitle("  one   two  "), "one two");
});

test("OSC extraction handles BEL, ST, and split chunks", () => {
  const first = consumeOscTitles("text\u001b]0;Codex - hello - app");
  assert.deepEqual(first.payloads, []);
  const second = consumeOscTitles("\u0007more\u001b]2;zsh\u001b\\", first.carry);
  assert.deepEqual(second.payloads, ["Codex - hello - app", "zsh"]);
  assert.equal(second.carry, "");
});
