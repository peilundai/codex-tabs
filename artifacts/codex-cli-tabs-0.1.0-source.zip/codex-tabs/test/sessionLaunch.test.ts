import assert from "node:assert/strict";
import test from "node:test";
import { sessionArguments } from "../src/sessionLaunch";

test("new, resume, and fork preserve global Codex argument ordering", () => {
  const global = ["--model", "gpt-5.6-terra"];
  assert.deepEqual(sessionArguments(global, "new"), global);
  assert.deepEqual(sessionArguments(global, "resume"), [...global, "resume"]);
  assert.deepEqual(sessionArguments(global, "fork"), [...global, "fork"]);
});
