# Architecture

Codex CLI Tabs is a thin editor integration around a user-installed Codex CLI.

```mermaid
flowchart LR
  Command["VS Code command"] --> Manager["CodexTerminalManager"]
  Manager --> Config["Validated settings"]
  Manager --> Cwd["Working-directory policy"]
  Manager --> Launch["Quoted launch plan"]
  Launch -->|"macOS/Linux + Python"| Pty["Extension pseudoterminal"]
  Pty --> Bridge["Python PTY adapter"]
  Bridge --> Codex["User-installed Codex CLI"]
  Launch -->|"fallback or Windows"| Native["VS Code terminal"]
  Native --> Codex
```

`src/codexTerminalManager.ts` is the stateful coordinator. Other modules
validate inputs, build immutable plans, or adapt one I/O boundary.

| Module | Responsibility |
| --- | --- |
| `configuration.ts` | Validate settings and bounded defaults. |
| `workingDirectory.ts` | Select the workspace/home directory. |
| `sessionLaunch.ts` | Place global arguments before `resume` or `fork`. |
| `launch.ts` | Quote executable arguments and create platform launch plans. |
| `pathMentions.ts` | Format verified resources as Codex `@` mentions. |
| `dropInterception.ts` | Detect an editor moved into a managed Codex group. |
| `titleParser.ts` | Parse bounded OSC terminal-title streams. |
| `pythonBridge.ts` | Detect Unix PTY support and build bridge arguments. |
| `codexPseudoterminal.ts` | Connect VS Code terminal events to the adapter. |
| `scripts/codex-pty-bridge.py` | Relay a Unix PTY, resize it, and rewrite verified path drops. |

Managed sessions are identified only by concrete `vscode.Terminal` objects.
Only terminals created during the current extension-host lifetime are managed.
The tabs themselves are transient; Codex CLI persists chat history and exposes
the native `resume` and `fork` pickers.

Configured executable and argument values are never interpreted as arbitrary
shell syntax. POSIX values are quoted individually. Windows default mode
launches the configured executable directly. The optional PTY adapter degrades
to a native terminal when unavailable.
