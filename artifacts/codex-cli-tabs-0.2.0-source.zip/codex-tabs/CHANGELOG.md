# Changelog

All notable changes follow [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

## [0.2.0] - 2026-08-16

### Added

- Automatic VS Code tab renaming when Codex generates or changes the current
  thread name.
- Distinct Codex app artwork for Marketplace and theme-aware tab icons.

## [0.1.0] - 2026-08-16

### Added

- Multiple independent Codex CLI sessions in reusable editor-area tabs.
- Native Codex `resume` and `fork` pickers in new tabs.
- File and folder insertion through context menus, editor moves, and verified
  path drops.
- Cross-platform launch planning with a dependency-free optional Unix PTY
  adapter and native-terminal fallback.
- Automated tests, package validation, architecture documentation, and explicit
  workspace trust restrictions.

[Unreleased]: https://github.com/peilundai/codex-tabs/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/peilundai/codex-tabs/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/peilundai/codex-tabs/releases/tag/v0.1.0
