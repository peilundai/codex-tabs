# Security policy

Report vulnerabilities with GitHub private security advisories rather than a
public issue. Include the extension and editor versions, platform, remote/local
extension-host details, a minimal reproduction, and expected impact. Do not
include credentials or private source code.

The extension launches the separately installed Codex executable with validated
arguments and a selected working directory. Codex code execution,
authentication, provider communication, and workspace modifications are outside
this extension's security boundary.

Extension-controlled surfaces are command construction, terminal lifecycle,
path insertion, editor-tab movement, the Unix PTY adapter, and package contents.
Untrusted and virtual workspaces are intentionally unsupported.
