# Codex CLI Tabs

An unofficial, open-source VS Code extension for running multiple independent
Codex CLI sessions as editor-area terminal tabs.

> This extension is not affiliated with or endorsed by OpenAI. Codex CLI must
> be installed and authenticated separately.

## Features

- Open Codex in an editor tab beside the current editor.
- Create multiple independent chats in one reusable editor group.
- Reveal the most recently used live Codex tab without creating a duplicate.
- Resume or fork a saved Codex chat in a new tab using the native CLI picker.
- Insert files and folders as relative or absolute `@` mentions.
- Move an editor tab into the Codex group to insert its path into the chat.
- Support local, multi-root, and remote workspaces.

Codex CLI remains responsible for conversations, persistence, authentication,
models, permissions, tools, and network traffic. This extension does not store
prompts, credentials, or chat history and does not collect telemetry.

## Requirements

Install and sign in to Codex CLI, then confirm it resolves in the environment
where the VS Code extension host runs:

```bash
codex --version
```

See the [official Codex CLI documentation](https://developers.openai.com/codex/cli/features)
for installation and authentication. On macOS and Linux, Python 3 with the
standard Unix `pty` module enables compact terminal titles and verified
file-drop rewriting.

## Commands

| Command | Description |
| --- | --- |
| **Codex Tabs: Open Agent** | Reveal the most recently used live tab, or create one. |
| **Codex Tabs: New Agent Chat** | Start an independent `codex` session. |
| **Codex Tabs: Resume Chat…** | Open `codex resume` in a new tab. |
| **Codex Tabs: Fork Chat…** | Open `codex fork` in a new tab. |
| **Codex Tabs: Insert into Chat** | Insert selected files or folders into the active Codex tab. |

The New Agent Chat command is also available from the editor title. Insert into
Chat is available from Explorer and editor context menus.

The resume and fork commands intentionally use Codex's native saved-session
picker. The [official CLI command reference](https://developers.openai.com/codex/cli/reference)
documents both commands and their working-directory behavior.

## Settings

| Setting | Default | Description |
| --- | --- | --- |
| `codexTabs.command` | `codex` | Executable name or absolute path. Shell expressions are not supported. |
| `codexTabs.args` | `[]` | Global CLI arguments placed before `resume` or `fork`. |
| `codexTabs.cwdMode` | `auto` | Working-directory policy: `auto`, `workspaceRoot`, or `prompt`. |
| `codexTabs.launchMode` | `loginShell` | Use a login shell on Unix or the configured terminal profile. |
| `codexTabs.titleMaxLength` | `28` | Maximum compact title length on macOS and Linux. |

Example:

```json
{
  "codexTabs.args": ["--model", "gpt-5.6-terra", "--no-alt-screen"]
}
```

## Platform support

- **macOS and Linux:** full support with Python 3 and Unix PTY modules.
- **Windows:** editor tabs, group reuse, commands, and context-menu insertion;
  Unix PTY title/drop integration is unavailable.
- **Remote environments:** supported when Codex CLI and Python are installed in
  the remote extension host.
- **Browser-only VS Code:** unsupported without a remote extension host.

If the optional Python adapter is unavailable, the extension falls back to a
native VS Code terminal. Core tab and command behavior remains available.

## Development

```bash
npm ci
npm run check
npm run package
```

See [CONTRIBUTING.md](CONTRIBUTING.md) and
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## License

MIT. See [NOTICE](NOTICE) for attribution and trademark information.
