export type SessionAction = "new" | "resume" | "fork";

export const MANAGED_TITLE_ARGUMENTS = [
  "-c",
  'tui.terminal_title=["app-name","thread"]',
] as const;

/** Places Codex global options before the optional session subcommand. */
export function sessionArguments(
  globalArguments: readonly string[],
  action: SessionAction,
): readonly string[] {
  const managedArguments = [...globalArguments, ...MANAGED_TITLE_ARGUMENTS];
  return action === "new"
    ? managedArguments
    : [...managedArguments, action];
}
